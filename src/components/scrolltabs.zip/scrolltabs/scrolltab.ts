export interface IScrollTab {
    name: string;
    image:string; 
    selected?: boolean;
}